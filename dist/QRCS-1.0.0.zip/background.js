import { safeWebURL, pixelRect } from './core.js';

const MENU = 'qrcs-image';
const PREFIX = 'qrcs-job-';
const MAX_AGE = 30 * 60 * 1000;
const scanning = new Set();

async function installMenu() {
  await chrome.contextMenus.removeAll();
  chrome.contextMenus.create({ id: MENU, title: 'QR码识别', contexts: ['image'] });
}
chrome.runtime.onInstalled.addListener(() => { void installMenu(); });

async function cleanJobs() {
  const all = await chrome.storage.session.get(null);
  const expired = Object.entries(all).filter(([key, job]) => key.startsWith(PREFIX) && Date.now() - job.created > MAX_AGE).map(([key]) => key);
  if (expired.length) await chrome.storage.session.remove(expired);
}

async function createJob(tab, extra) {
  await cleanJobs();
  const id = crypto.randomUUID();
  const job = { id, created: Date.now(), tabId: tab.id, windowId: tab.windowId, ...extra };
  await chrome.storage.session.set({ [PREFIX + id]: job });
  return job;
}
async function getJob(id) {
  if (typeof id !== 'string' || !/^[0-9a-f-]{36}$/.test(id)) throw new Error('识别任务无效。');
  const job = (await chrome.storage.session.get(PREFIX + id))[PREFIX + id];
  if (!job || Date.now() - job.created > MAX_AGE) throw new Error('识别任务已结束，请重新点击插件。');
  return job;
}
async function saveJob(job) { await chrome.storage.session.set({ [PREFIX + job.id]: job }); }
async function openView(job) {
  const win = await chrome.windows.create({ url: chrome.runtime.getURL('scanner.html') + '?job=' + job.id,
    type: 'popup', width: job.mode === 'select' ? 1160 : 620, height: job.mode === 'select' ? 800 : 650, focused: true });
  job.viewWindowId = win.id;
  await saveJob(job);
}

async function capture(tab) {
  const check = async () => {
    const [active] = await chrome.tabs.query({ active: true, windowId: tab.windowId });
    if (active?.id !== tab.id) throw new Error('标签页已切换，请在二维码所在标签页重新扫描。');
  };
  await check();
  const image = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
  await check();
  return image;
}
export async function beginSelection(tab) {
  if (scanning.has(tab.id)) return;
  scanning.add(tab.id);
  try {
    // Remove any old selection before taking a clean new screenshot.
    await chrome.tabs.sendMessage(tab.id, { type: 'QRCS_CLOSE_OVERLAY' }).catch(() => {});
    const screenshot = await capture(tab);
    const job = await createJob(tab, { mode: 'select', screenshot });
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['selection.js'] });
      const reply = await chrome.tabs.sendMessage(tab.id, { type: 'QRCS_SELECT', jobId: job.id, screenshot });
      if (!reply?.ok) throw new Error('页面框选不可用');
    } catch {
      // data: image pages / browser pages cannot host a content script.
      await openView(job);
    }
  } catch (error) {
    const job = await createJob(tab, { mode: 'error', error: '无法截取当前页面：' + error.message });
    await openView(job);
  } finally { scanning.delete(tab.id); }
}

chrome.action.onClicked.addListener(tab => { void beginSelection(tab); });
export async function beginImage(info, tab) {
  let screenshot;
  try { screenshot = await capture(tab); } catch { /* Original image can still be decoded. */ }
  const imageUrl = info.srcUrl;
  const valid = typeof imageUrl === 'string' && /^(https?:|data:image\/|blob:)/i.test(imageUrl);
  const job = await createJob(tab, valid ? { mode: 'image', imageUrl, screenshot }
    : { mode: 'error', error: '无法读取这张图片，请点击插件图标进行截图框选。', screenshot });
  await openView(job);
}
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== MENU || !tab) return;
  void beginImage(info, tab);
});

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!message || typeof message.type !== 'string' || !message.type.startsWith('QRCS_')) return;
  const internal = sender.id === chrome.runtime.id && sender.url?.startsWith(chrome.runtime.getURL('scanner.html'));
  void (async () => {
    const job = await getJob(message.jobId);
    if (message.type === 'QRCS_CROP' || message.type === 'QRCS_CANCEL_OVERLAY') {
      if (sender.id !== chrome.runtime.id || sender.tab?.id !== job.tabId) throw new Error('页面与任务不匹配。');
      if (message.type === 'QRCS_CANCEL_OVERLAY') {
        await chrome.storage.session.remove(PREFIX + job.id);
      } else {
        pixelRect(message.rect, 1000, 1000);
        job.mode = 'crop'; job.rect = message.rect;
        await saveJob(job); await openView(job);
      }
      return { ok: true };
    }
    if (!internal) throw new Error('不允许的请求来源。');
    switch (message.type) {
      case 'QRCS_GET_JOB': return { ok: true, job };
      case 'QRCS_DROP_JOB': await chrome.storage.session.remove(PREFIX + job.id); return { ok: true };
      case 'QRCS_OPEN_URL': {
        const url = safeWebURL(message.url);
        if (!url) throw new Error('仅支持打开有效的 HTTP / HTTPS 网页链接。');
        await chrome.tabs.create({ url, windowId: job.windowId, active: true });
        return { ok: true };
      }
      default: throw new Error('未知操作。');
    }
  })().then(respond, error => respond({ ok: false, error: error.message }));
  return true;
});

chrome.windows.onRemoved.addListener(windowId => {
  void chrome.storage.session.get(null).then(all => {
    const keys = Object.entries(all).filter(([key, job]) => key.startsWith(PREFIX) && job.viewWindowId === windowId).map(([key]) => key);
    if (keys.length) return chrome.storage.session.remove(keys);
  });
});
