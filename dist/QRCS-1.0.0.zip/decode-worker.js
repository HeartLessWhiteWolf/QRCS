importScripts('vendor/jsQR.js', 'decode-engine.js');
self.onmessage = ({ data }) => {
  try {
    const results = QRCSDecode(data.pixels, data.width, data.height);
    self.postMessage({ ok: true, results });
  } catch (error) { self.postMessage({ ok: false, error: error.message }); }
};
