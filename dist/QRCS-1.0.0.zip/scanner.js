import { safeWebURL, selectionRect, pixelRect, resultKind } from './core.js';

const $ = id => document.getElementById(id);
const jobId = new URL(location.href).searchParams.get('job');
let job, activeWorker, workerTimer, selectedText = '', drawStart, operation = 0;
let wholeScreenshotFallback = false;
const request = async (type, extra = {}) => {
  const reply = await chrome.runtime.sendMessage({ type, jobId, ...extra });
  if (!reply?.ok) throw new Error(reply?.error || '扩展连接已断开，请重新打开。');
  return reply;
};
function show(id) {
  for (const panel of ['loading', 'select', 'result', 'error']) $(panel).hidden = panel !== id;
}
function stopWorker() {
  activeWorker?.terminate(); activeWorker = null; clearTimeout(workerTimer);
}
function showError(message) {
  stopWorker(); $('error-message').textContent = message;
  $('error-retry').hidden = !job?.screenshot; show('error');
}
async function closeView() {
  operation++; stopWorker();
  await request('QRCS_DROP_JOB').catch(() => {});
  window.close();
}
function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      if (!img.naturalWidth || !img.naturalHeight) reject(new Error('图片为空。'));
      else resolve(img);
    };
    img.onerror = () => reject(new Error('图片格式无法读取，请改用截图框选。'));
    img.src = src;
  });
}
async function originalImage(src) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  let objectURL;
  try {
    const response = await fetch(src, { signal: controller.signal, credentials: 'include', referrerPolicy: 'no-referrer' });
    if (!response.ok) throw new Error('图片服务器拒绝读取（' + response.status + '）。');
    if (Number(response.headers.get('content-length')) > 24 * 1024 * 1024) throw new Error('原图过大，请改用截图框选。');
    const blob = await response.blob();
    if (blob.size > 24 * 1024 * 1024) throw new Error('原图过大，请改用截图框选。');
    objectURL = URL.createObjectURL(blob);
    return await loadImage(objectURL);
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('原图读取超时，请改用截图框选。');
    throw error;
  } finally { clearTimeout(timer); if (objectURL) URL.revokeObjectURL(objectURL); }
}
function runWorker(imageData) {
  stopWorker();
  return new Promise((resolve, reject) => {
    const worker = new Worker(chrome.runtime.getURL('decode-worker.js'));
    activeWorker = worker;
    const finish = (error, value) => { stopWorker(); error ? reject(error) : resolve(value); };
    workerTimer = setTimeout(() => finish(new Error('识别耗时较长，请缩小选区后重试。')), 15000);
    worker.onerror = () => finish(new Error('解码模块未能启动，请重新加载扩展。'));
    worker.onmessage = ({ data }) => data.ok ? finish(null, data.results) : finish(new Error(data.error));
    worker.postMessage({ pixels: imageData.data.buffer, width: imageData.width, height: imageData.height }, [imageData.data.buffer]);
  });
}
async function decodeImage(image, rect) {
  const token = ++operation;
  show('loading');
  const region = rect ? pixelRect(rect, image.naturalWidth, image.naturalHeight)
    : { x: 0, y: 0, width: image.naturalWidth, height: image.naturalHeight };
  const limit = Math.min(1, 2200 / Math.max(region.width, region.height));
  const scales = [...new Set([limit, limit * .65, Math.min(3, 900 / Math.max(region.width, region.height))])];
  for (let index = 0; index < scales.length; index++) {
    if (token !== operation) return;
    $('loading-detail').textContent = index ? '正在尝试调整图像尺寸…' : '正在本地解码，请稍候…';
    const width = Math.max(1, Math.round(region.width * scales[index]));
    const height = Math.max(1, Math.round(region.height * scales[index]));
    const canvas = document.createElement('canvas'); canvas.width = width + 32; canvas.height = height + 32;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.imageSmoothingEnabled = scales[index] < 1;
    ctx.drawImage(image, region.x, region.y, region.width, region.height, 16, 16, width, height);
    const results = await runWorker(ctx.getImageData(0, 0, canvas.width, canvas.height));
    canvas.width = canvas.height = 1;
    if (token !== operation) return;
    if (results.length) { showResults(results); return; }
  }
  throw new Error('未找到可识别的二维码。请完整框住二维码，保留四周留白，并避开遮挡和模糊区域。');
}
function showResults(results) {
  $('result-summary').textContent = wholeScreenshotFallback
    ? `原图未能识别，以下是网页截图中找到的 ${results.length} 个不同内容，请核对是否为目标二维码。`
    : results.length === 1 ? '请核对内容，再决定是否打开。' : `识别到 ${results.length} 个不同内容，请选择要查看的结果。`;
  const tabs = $('result-tabs'); tabs.replaceChildren();
  const choose = index => {
    selectedText = results[index].text;
    const text = selectedText || '（二维码包含二进制数据，无法作为文本显示）\n十六进制：' + results[index].binary.map(x => x.toString(16).padStart(2, '0')).join(' ');
    $('content').textContent = text;
    $('kind').textContent = selectedText ? resultKind(selectedText) : '二进制数据';
    $('char-count').textContent = `${Array.from(selectedText).length} 字符`;
    const url = safeWebURL(selectedText);
    $('open').disabled = !url;
    $('url-note').textContent = url ? '即将在新标签页打开：' + new URL(url).hostname : '此内容不是可直接打开的 HTTP / HTTPS 网页链接，可复制使用。';
    $('feedback').textContent = '';
    $('copy').disabled = !selectedText;
    [...tabs.children].forEach((tab, i) => tab.setAttribute('aria-pressed', String(i === index)));
  };
  if (results.length > 1) results.forEach((_result, index) => {
    const button = document.createElement('button'); button.textContent = '结果 ' + (index + 1);
    button.onclick = () => choose(index); tabs.append(button);
  });
  $('retry').hidden = !job.screenshot;
  choose(0); show('result');
}
async function showSelection() {
  operation++; stopWorker(); drawStart = undefined;
  wholeScreenshotFallback = false;
  if (!job?.screenshot) { showError('没有可用截图，请回到网页重新点击插件图标。'); return; }
  $('selection-box').style.display = 'none';
  $('screenshot').src = job.screenshot;
  $('select-hint').textContent = '拖动框住二维码，松开鼠标识别。请保留二维码四周留白。';
  show('select'); $('stage').focus();
}
const stage = $('stage');
const localPoint = event => {
  const bounds = stage.getBoundingClientRect();
  return { x: Math.min(bounds.width, Math.max(0, event.clientX - bounds.left)), y: Math.min(bounds.height, Math.max(0, event.clientY - bounds.top)) };
};
stage.addEventListener('pointerdown', event => {
  if (event.button !== 0) return;
  event.preventDefault(); drawStart = localPoint(event); stage.setPointerCapture(event.pointerId);
  Object.assign($('selection-box').style, { display: 'block', left: drawStart.x + 'px', top: drawStart.y + 'px', width: '0px', height: '0px' });
});
stage.addEventListener('pointermove', event => {
  if (!drawStart) return;
  const point = localPoint(event);
  Object.assign($('selection-box').style, { left: Math.min(drawStart.x, point.x) + 'px', top: Math.min(drawStart.y, point.y) + 'px', width: Math.abs(drawStart.x - point.x) + 'px', height: Math.abs(drawStart.y - point.y) + 'px' });
});
stage.addEventListener('pointercancel', () => { drawStart = undefined; $('selection-box').style.display = 'none'; });
stage.addEventListener('pointerup', event => {
  if (!drawStart) return;
  const bounds = stage.getBoundingClientRect();
  const rect = selectionRect(drawStart, localPoint(event), bounds.width, bounds.height);
  drawStart = undefined;
  if (!rect) { $('selection-box').style.display = 'none'; $('select-hint').textContent = '选区太小，请重新拖动框住整个二维码。'; return; }
  void loadImage(job.screenshot).then(image => decodeImage(image, rect)).catch(error => showError(error.message));
});
window.addEventListener('resize', () => { drawStart = undefined; $('selection-box').style.display = 'none'; });
document.addEventListener('keydown', event => { if (event.key === 'Escape') void closeView(); });
for (const id of ['cancel', 'error-cancel', 'select-cancel']) $(id).onclick = closeView;
for (const id of ['retry', 'error-retry']) $(id).onclick = showSelection;
$('open').onclick = async () => {
  if (!safeWebURL(selectedText)) return;
  $('open').disabled = true;
  try { await request('QRCS_OPEN_URL', { url: selectedText }); await closeView(); }
  catch (error) { $('feedback').textContent = error.message; $('open').disabled = false; }
};
$('copy').onclick = async () => {
  try { await navigator.clipboard.writeText(selectedText); $('feedback').textContent = '已复制内容'; }
  catch { $('feedback').textContent = '未能写入剪贴板，请选中上方内容后按 Ctrl+C。'; }
};
window.addEventListener('pagehide', () => { stopWorker(); void request('QRCS_DROP_JOB').catch(() => {}); });

try {
  job = (await request('QRCS_GET_JOB')).job;
  if (job.mode === 'error') showError(job.error);
  else if (job.mode === 'select') await showSelection();
  else if (job.mode === 'crop') await decodeImage(await loadImage(job.screenshot), job.rect);
  else {
    try { await decodeImage(await originalImage(job.imageUrl)); }
    catch (originalError) {
      if (!job.screenshot) throw originalError;
      wholeScreenshotFallback = true;
      $('loading-detail').textContent = '原图未能识别，正在尝试网页截图…';
      try { await decodeImage(await loadImage(job.screenshot)); }
      catch { throw new Error(originalError.message + ' 可点击「重新框选」，从截图中选择二维码。'); }
    }
  }
} catch (error) { showError(error.message); }
